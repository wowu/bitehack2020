self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4d841fbafee91225dc5015ff76c3ade4",
    "url": "/index.html"
  },
  {
    "revision": "47147711f66ec2bfb25b",
    "url": "/static/css/main.e6ad4351.chunk.css"
  },
  {
    "revision": "0e33eb66f9f05410800b",
    "url": "/static/js/2.6735f5e0.chunk.js"
  },
  {
    "revision": "138a6d51240ab070e8d1b20c54be6394",
    "url": "/static/js/2.6735f5e0.chunk.js.LICENSE"
  },
  {
    "revision": "47147711f66ec2bfb25b",
    "url": "/static/js/main.e16ab196.chunk.js"
  },
  {
    "revision": "b5ff61001688404db26f",
    "url": "/static/js/runtime-main.8c5f780f.js"
  },
  {
    "revision": "bf4f031753615eb334af24930bd9f090",
    "url": "/static/media/kanban.bf4f0317.png"
  },
  {
    "revision": "0b57a90c82f132f25dca98d1bd3e66fd",
    "url": "/static/media/master_plan.0b57a90c.svg"
  }
]);