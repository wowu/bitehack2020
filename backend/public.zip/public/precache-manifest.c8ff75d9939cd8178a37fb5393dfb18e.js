self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7743e46b9b0c92c44ec12cabaa9daa9a",
    "url": "/index.html"
  },
  {
    "revision": "4caa498fdcf007204dd5",
    "url": "/static/css/main.e05b4538.chunk.css"
  },
  {
    "revision": "51c10c65b0e214c31048",
    "url": "/static/js/2.05b890f1.chunk.js"
  },
  {
    "revision": "138a6d51240ab070e8d1b20c54be6394",
    "url": "/static/js/2.05b890f1.chunk.js.LICENSE"
  },
  {
    "revision": "4caa498fdcf007204dd5",
    "url": "/static/js/main.c08aac1b.chunk.js"
  },
  {
    "revision": "b5ff61001688404db26f",
    "url": "/static/js/runtime-main.8c5f780f.js"
  },
  {
    "revision": "bf4f031753615eb334af24930bd9f090",
    "url": "/static/media/kanban.bf4f0317.png"
  },
  {
    "revision": "0b57a90c82f132f25dca98d1bd3e66fd",
    "url": "/static/media/master_plan.0b57a90c.svg"
  }
]);