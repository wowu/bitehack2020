self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "56a740b69c599c337f9bab1f4ac1d96a",
    "url": "/index.html"
  },
  {
    "revision": "f4770970d7acdefc9089",
    "url": "/static/css/main.e05b4538.chunk.css"
  },
  {
    "revision": "51c10c65b0e214c31048",
    "url": "/static/js/2.05b890f1.chunk.js"
  },
  {
    "revision": "138a6d51240ab070e8d1b20c54be6394",
    "url": "/static/js/2.05b890f1.chunk.js.LICENSE"
  },
  {
    "revision": "f4770970d7acdefc9089",
    "url": "/static/js/main.79fed88b.chunk.js"
  },
  {
    "revision": "b5ff61001688404db26f",
    "url": "/static/js/runtime-main.8c5f780f.js"
  },
  {
    "revision": "bf4f031753615eb334af24930bd9f090",
    "url": "/static/media/kanban.bf4f0317.png"
  },
  {
    "revision": "0b57a90c82f132f25dca98d1bd3e66fd",
    "url": "/static/media/master_plan.0b57a90c.svg"
  }
]);